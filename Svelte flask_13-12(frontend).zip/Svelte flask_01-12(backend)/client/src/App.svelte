<script lang="ts">
	import TrocaTela from "./components/controls/TrocaTela.svelte";
</script>

<main>
	<TrocaTela>
	</TrocaTela>
</main>
	
<style>
	@media (min-width: 320px) {
		:global(body) {
			max-width: none;
			background-color: #B1D0E026;
			text-align: center;
			display: flex;
			justify-content: center;
		}
	}

	:root {
		--cor-fundo: #B1D0E026;
	}
	
</style>