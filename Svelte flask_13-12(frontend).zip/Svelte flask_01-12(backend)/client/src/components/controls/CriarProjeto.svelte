<script>
    import { tela } from "../../store";

    export let nomeProjeto = "";
    export let prioridade = "";
    export let status = "";
    export let dialog;

    let prioridades = [
        {value: 'Low', label: 'Baixa'},
        {value: 'Medium', label: 'Média'},
        {value: 'High', label: 'Alta'}
    ];

    let statusOption = [
        {value: 'Stable', label: 'Estável'},
        {value: 'Urgent', label: 'Urgente'},
        {value: 'Postponable', label: 'Adiável'},
    ];

    async function adicionarProjeto(e) {
        let retorno = await fetch(`./create?nomeprojeto=${nomeProjeto}&prioridade=${prioridade}&status=${status}`);
        tela.update( v => "projetos");
}
</script>

<dialog class="criarProjeto" bind:this={dialog}>
    <header class="cabeProjeto">
        <h1>Criar Projeto</h1>
    </header>

    <div class="funciProjeto">
        <div class="name">
            <h2>Nome do Projeto:</h2>
            <input type="text" name="Name" id="Name" bind:value={nomeProjeto} required>
            <!--<span>{nomeProjeto}</span>
            <span>{prioridade}</span>
            <span>{status}</span>--->
        </div>
        
        <div class="prio">
            <h3>Prioridade:</h3>
            <select name="prioridade" bind:value={prioridade}>
                {#each prioridades as option}
                {#if option.value == prioridade}
                    <option value="{option.value}" selected>{option.label}</option>
                {:else}
                    <option value="{option.value}">{option.label}</option>
                {/if} 
                {/each}
            </select>
        </div>
            
        <div class="status">
            <h3>Status:</h3>
            <select name="status" bind:value={status}>
                {#each statusOption as option}
                {#if option.value == status}
                    <option value="{option.value}" selected>{option.label}</option>
                {:else}
                    <option value="{option.value}">{option.label}</option>
                {/if} 
                {/each}
            </select>
        </div>

        <div class="confirmar">
            <button class="projeto" on:click={adicionarProjeto}>
                Confirmar
            </button>
        </div>
    </div>
</dialog>

<style>
    .criarProjeto {
        font-family: 'Poppins';
        font-style: normal;
        position: absolute;
        background-color: #FAFDFD;
        width: 322px;
        height: 339px;
        padding: 0px;
        border-radius: 10px;
        border: 1px solid rgba(0, 0, 0, 0.1);
        box-shadow: 0px 1px 2px rgb(0 0 0 / 5%);
    }

    .cabeProjeto {
        background-color: #406882;
        color: white;
        margin: 0px;
    }

    .name {
        display: flex;
        align-items: center;
    }

    .prio, .status {
        display: flex;
        align-items: center;
    }

    .projeto {
        color: white;
        background: #406882;
        border: 1px solid #000000;
        padding: 4px 78px;
        box-shadow: 0px 3px 2px rgb(0 0 0 / 15%);
        border-radius: 10px;
        margin-top: 10px;
    }
</style>