<script lang="ts">
    import Login from '../../controle-horas/login.svelte';
    import Estatisticas from '../../controle-horas/estatisticas.svelte';
    import Boasvindas from '../../controle-horas/boasvindas.svelte';
    import Projetos from '../../controle-horas/projetos.svelte';
    import Cronometro from '../../controle-horas/cronometro.svelte';

    import { tela } from '../../store';

    let estado = "padrao";

    tela.subscribe(value => estado = value);

</script>

<div class="trocadorDeTelas">
    {#if estado === "boasvindas"}
        <Boasvindas/>
    {:else if estado === "estatisticas"}
        <Estatisticas/>
    {:else if estado === "projetos" }
        <Projetos/>
    {:else if estado === "cronometro" }
        <Cronometro/>   
    {:else if estado === "padrao" }
        <Login/>
    {/if}
</div>