<script lang="ts">
    import { tela } from "../../store";

    function telaMenu(event) {
        tela.update( v => "estatisticas");
    }
</script>

<div class="estruturacabecalho">

    <div class="cabecalho">
        <ul>
            <li class="icones01">
                    <img src="vetores/perfil.svg" class="perfil" alt="Perfil">
                        <div class="barradepesquisa"> 
                            <img src="vetores/pesquisa.svg" class="pesquisa" alt="Pesquisa">
                            <input type="text" placeholder="Search"> 
                        </div>
                    <img src="vetores/chat.svg" class="chat" alt="chat">
            </li>
        </ul>
    </div>
    
    <slot></slot>
    
    <div class="ropade">
        <ul>
            <li class="icones02">
                <button class='btnIcon' on:click={telaMenu}>
                    <img src="vetores/menu.svg" alt="menu">
                </button>
            
                <button class='btnIcon'>
                    <img src="vetores/calendario.svg" alt="calendario">
                </button>
        
                <button class='btnIcon'>
                    <img src="vetores/verificado.svg" alt="verificado">
                </button>
                
                <button class='btnIcon'>
                    <img src="vetores/pontos.svg" alt="pontos">
                </button>
            </li>
        </ul>
    </div>
      
</div>

<style>
    .estruturacabecalho {
        display: grid;
        justify-items: center;
        margin-top: -8px;
    }

    ul {
        margin: 0%;
        padding: 0%;
    }

    .btnIcon {
        background-color: #406882;
        cursor: pointer;
        border: none;
        margin: 0px;
        padding: 0px;
    }

    .btnIcon:focus {
        border-bottom:1px solid rgba(255, 255, 255, 0.815);
        border-radius: 80px;
    }

    .icones01, .icones02 {
        width: 393px;
        height: 52px;
        border-radius: 0px 0px 20px 20px;
        list-style: none;
        background: #406882;
    }

    .icones02 {
        display: flex;
        justify-content: space-evenly;
        border-radius: 20px 20px 0px 0px;
        padding-bottom: 5px;
        padding-top: 5px;
    }    

    .perfil {
        vertical-align: middle;
        margin-right: 320px;
        margin-top: 6px;
        align-items: center;
    }

    
    .barradepesquisa {
        width: 246px;
        height: 35px;
        border-radius: 40px;
        margin-top: -38px;
        margin-left: 72px;
        box-shadow: 10px;
        display: flex;
        background: white;
    }

    .pesquisa {
        vertical-align: middle;
        height: 30px;
        width: 20px;
        margin-top: 3px;
        margin-left: 12px;
    }

    .icones01 input {
        width: 214px;
        height: 35px;
        border-radius: 40px;
        margin-top: 1px;
        background: transparent;
        border: none;
}

    .chat {
        vertical-align: middle;
        margin-left: 320px;
        margin-top: -54px;
    }

    .icones02 img {
        margin-top: 6px;
    }
</style>