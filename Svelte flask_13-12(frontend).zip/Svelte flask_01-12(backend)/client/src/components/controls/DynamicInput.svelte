<script>
    export let name = "";
    export let id = "";
    export let placeholder = "";
    export let description = "";
    export let value = "";
    export let type = "text";
    export let required = false;
    export let icon = '';

    let isPassword = (type == "password"),
        showPassword = false,
        vector = 'vetores/hide.png';

    function handleInput(e){
        value = type.match('/^(number|range)$/')
            ? +e.target.value
            : e.target.value;
    }

    function togglePassword(e){
        showPassword = !showPassword;
        type = !showPassword ? 'password' : 'text';
        vector = `vetores/${showPassword ? 'show' : 'hide'}.png`;
    }

</script>

<div class="input-wrapper {name}">
    <img src="{icon}" alt="{description}" id="{id}-img" class="icon"> 
    <input {type} {name} {id} {placeholder} {required} {value} on:input={handleInput}/>
    {#if isPassword }
    <a on:click={togglePassword}>
        <img src="{vector}" alt="{description}" id="{id}-toggle" class="toggle">
    </a>
    {/if}
</div>

<style>
    .input-wrapper {
        border: 1px solid #000000;
        border-color: black;
        background-color: #FAFAFA;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        border-radius: 10px;
        display: inline-flex;
        padding: 2px;
    }

    input {
        background: transparent;
        border: none;
        margin-bottom: 0px;
        width: 284px;
    }

    img {
        width: 32px;
        height: 32px;
    }

    img.icon {
        vertical-align: middle;
    }

    img.toggle {
        position: absolute;
        background-size: cover;
        cursor: pointer;
        margin-left: -33px;
    }
</style>