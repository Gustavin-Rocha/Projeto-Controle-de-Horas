<script lang="ts">
    import { tela } from "../store";

    let name = '';

// Função responsável pela exibição do nome do usuário (backend)
    async function nome(e) {

let retorno = await fetch(`./user`)
let mensagem_form = await retorno.text();
name = mensagem_form

 }

    function onClick(event){
        tela.update( v => "estatisticas");
    }

    nome(1);
</script>

<div class="boasvindas">

    <div class="usuario">
        <h1 class="titulo">Olá {name}!</h1>
        <h2 class="titulo">Você tem 4 <br> tarefas pendentes.</h2>
    </div>

    <div class="projetos">

        <div class="projetoatual">
            <h1 class="textnumber" style="margin-botton: 10px;">Mobile App Design</h1>
            <p1 class="text">Mike and Laiz</p1>
            <p2 class="text">Now</p2>
        </div>

        <div class="box">
            <div class="box1">
                <div class="feitos">
                    <h1 class="textnumber">22</h1>
                    <p1 class="text">Done</p1>
                </div>
        
                <div class="emandamento">
                    <h1 class="textnumber">10</h1>
                    <p class="text">Ongoing</p>
                </div>
            </div>

            <div class="box2">
                <div class="emprogresso">
                    <h1 class="textnumber">7</h1>
                    <p1 class="text">In Progress</p1>
                </div>
        
                <div class="revisao">
                    <h1 class="textnumber">12</h1>
                    <p1 class="text">Waiting for Review</p1>
                </div>
            </div>
        </div>
              
    </div>

    <button class="prosseguir" on:click={onClick}>
        Prosseguir
    </button>

</div>

<slot></slot>

<style>

    .titulo {
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 600;
        font-size: 2rem;
        letter-spacing: 0.015em;
        color: #000000;
    }

    .textnumber {
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 600;
        font-size: 1.2rem;
        letter-spacing: 0.015em;
        color: #FFFFFF;
        margin: 0px;
    }

    .text {
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 400;
        font-size: 0.7rem;
        letter-spacing: 0.015em;
        color: rgba(229, 239, 245, 0.75);
    }

    .boasvindas {
        background-image: url('../vetores/digitaltransparente.svg');
        background-repeat: no-repeat;
        background-position: 52% 10%;
        background-size: 400px 318px;
    }

    .usuario {
        text-align: left;
        display: inline-block;
    }

    .projetos {
        display: flex;
        flex-direction: column;
    }

    .box {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 10px;

    }

    .projetoatual {
        width: 256px;
        height: 90px;
        border-radius: 15px;
        padding: 10px;
        font-size: 0.6rem;
        display: flex;
        margin: auto;
        flex-direction: column;
        align-items: flex-start;
        color: white;
        background-color: #406882;
        justify-content: space-around;
    }

    .feitos {
        width: 92px;
        height: 88px;
        border-radius: 15px;
        padding: 10px;
        font-size: 0.6rem;
        display: flex;
        margin: 10px auto;
        flex-direction: column;
        align-items: center;
        color: white;
        background-color: #406882;
        justify-content: space-evenly;
    }

    .emandamento {
        width: 96px;
        height: 44px;
        border-radius: 15px;
        padding: 10px;
        font-size: 0.6rem;
        display: flex;
        margin: 10px auto;
        align-items: center;
        justify-content: space-around;
        color: white;
        background-color: #406882;
    }

    .emprogresso {
        width: 120px;
        height: 29px;
        border-radius: 15px;
        padding: 10px;
        font-size: 0.6rem;
        display: flex;
        margin: 10px auto;
        display: inline-table;
        align-items: center;
        justify-content: center;
        color: white;
        background-color: #406882;
    }

    .revisao {
        width: 120px;
        height: 85px;
        border-radius: 15px;
        padding: 10px;
        font-size: 0.6rem;
        display: flex;
        margin: 10px auto;
        align-items: center;
        justify-content: space-around;
        color: white;
        background-color: #406882;
        flex-direction: column;
    }

    .box2 {
        margin-left: 10px;
    }

    .prosseguir {
        width: 264px;
        height: 32px;
        font-size: 0.8rem;
        border-radius: 10px;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        font-family: 'Roboto';
        font-style: normal;
        color: white;
        background: #406882;
        border: 1px solid #000000;
    }
</style>