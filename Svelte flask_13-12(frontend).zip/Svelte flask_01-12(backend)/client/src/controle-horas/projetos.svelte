<script>
    import { tela } from "../store";
    import Cabecalho from "../components/controls/Cabecalho.svelte";   

function iniciarTarefa(event) {
    tela.update( v => "cronometro");
}
</script>

<Cabecalho>
<div class="geral">
    <div class="nomeProjeto">
        <div class="nome">
            <h1>Nome do Projeto</h1>

            <button class="cronometro" on:click={iniciarTarefa}>
                <img src="vetores/novatarefa.svg" alt="Play">
            </button>
        </div>
    </div>
    

    <h1 class="improvisado">As informações das Tarefas <br> vão aparecer aqui!</h1>


</div>
</Cabecalho>

<style>
    .geral {
        font-family: 'Poppins';
        font-style: normal;
        font-size: 12px;
    }

    .nomeProjeto {
        background-color: #6998AB;
        color: white;
        width: 392px;
        height: 158px;
        border-radius: 0px 0px 20px 20px;
        letter-spacing: 1px;
    }

    .nome {
        display: flex;
        justify-content: space-between;
        padding: 96px 24px 10px 24px;
    }

    .cronometro {
        background: transparent;
        border: none;
    }

    .improvisado {
        opacity: 0.5;
    }
</style>