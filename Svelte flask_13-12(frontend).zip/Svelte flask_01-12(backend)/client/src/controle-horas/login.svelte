<script lang="ts">
    import { tela } from '../store';
    import DynamicInput from '../components/controls/DynamicInput.svelte';
    
    let estado = "padrao",
        inpPassType = 'password';

    let mensagem = '';

    function trocaEstado(novo) {
        estado = novo
    }

    function vaiParaEmailSenha(){
        trocaEstado('email/senha')
    }

    function vaiParaTelaInicial(){
    tela.update(v => "boasvindas");
    estado = "oculto";
    }

    function esqueceuSenha() {
        trocaEstado('redefinir')
    }

    function cliqueAqui() {
        trocaEstado('cadastro')
    }

    let comSucesso = false;
    let preencher = false;
    let valores = {
        usuario: null,
        senha: null
    };
    
    const erroMensagem = "Preencha este Campo!";

//Função responsável pela verificação de email e senha (backend)
    async function handleSubmit(e) {

    let retorno = await fetch(`./login?email=${valores.usuario}&senha=${valores.senha}`)
    let mensagem_form = await retorno.text();

    if (mensagem_form == "Usuário ou senha incorretos"){
    mensagem = mensagem_form;
    }
    
    if (!valores.usuario || !valores.senha){
        comSucesso = false;
    } else {
        comSucesso = true;
    }

    if (mensagem_form == "Usuário e senha corretos") {
     
    if (comSucesso){
        vaiParaTelaInicial();
     }

    setTimeout(function(){
        comSucesso = false;
     }, 4000);
    }
}
</script>

<div id="login" class="login01" style='display: {estado=="padrao" ? "grid" : "none" }'>
    <h1 class='titLogin'>Login</h1> 

    <button class="facebook" on:click = {vaiParaEmailSenha}>
        <img src="vetores/Facebook.svg" alt="Facebook"> Continuar com o Facebook
    </button>
        
    <button class="google" on:click = {vaiParaEmailSenha}>
        <img src="vetores/google.svg" alt="Google"> Continuar com o Google
    </button>

    <div class="escolha">
        <p> <strong>ou</strong> </p>
    </div>

    <button class="entrar" on:click = {vaiParaEmailSenha}>
        Entrar
    </button>
</div>

<div class="login02" style='display: {estado=="email/senha" ? "grid" : "none" }'>
    <h1 class='titLogin'>Login</h1> 

    <form class:preencher on:submit|preventDefault={handleSubmit}>
        <DynamicInput id="usuario" name="usuario" placeholder="Digite seu e-mail" type="email" bind:value={valores.usuario} icon="vetores/Mail.svg" required/>
        <DynamicInput id="senha" name="senha" placeholder="Digite sua senha" type="password" bind:value={valores.senha} icon="vetores/Lock.svg" required/> 
    
        <div class="esqueceusenha" style='display: {estado!=="padrao" ? "grid" : "none" }' on:click={esqueceuSenha}>
            <p> <strong>Esqueceu a senha?</strong> </p>
        </div>
    
        <button class="iniciar" on:click={handleSubmit}>
            Iniciar Sessão
        </button>

        <div class="cadastro" style='display: {estado!=="padrao" ? "grid" : "none" }' on:click={cliqueAqui}>
            <p> <strong>Não possui cadastro? <span> Clique aqui </span> </strong> </p>
        </div>
    </form> 
</div>

        <h3>{mensagem}</h3>
<style>
    .titLogin {
        font-family: 'Poppins';
        font-style: normal;
    }

    .login01 {
        font-family: 'Roboto';
        font-style: normal;
        margin-left: auto;
        background-image: url('../vetores/digital.svg');
        background-repeat: no-repeat;
        justify-content: center;
        background-size: 226px 372px;
        grid-gap: 20px;
        background-position: right;
    }

    .facebook {
        border: 1px solid #000000;
        border-color: black;
        background-color: #FAFAFA;
        border-radius: 10px;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        width: 308px;
        height: 50px;
    }

    .facebook img {
        vertical-align: middle;
    }

    .google {
        border: 1px solid #000000;
        border-color: black;
        background-color: #FAFAFA;
        border-radius: 10px;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        width: 308px;
        height: 50px;
    }

    .google img {
        vertical-align: middle;
    }

    .entrar {
        border: 1px solid #000000;
        border-color: black;
        background-color: #FAFAFA;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        margin-top: 10px;
        border-radius: 10px;
        width: 308px;
        height: 50px;
        display: flex !important;
        align-items: center;
        justify-content: center;
    }

    .login02 form {
        font-family: 'Roboto';
        font-style: normal;
        display: grid;
        margin-left: auto;
        margin-right: auto;
        background-image: url('../vetores/digital.svg');
        background-repeat: no-repeat;
        justify-content: center;
        background-size: 226px 372px;
        grid-gap: 20px;
        background-position: right;
    }

    .esqueceusenha {
        margin-top: -27px;
        margin-left: 200px;
        font-size: 14px;

    }

    .iniciar {
        color: white;
        background: #406882;
        border: 1px solid #000000;
        box-shadow: 0px 3px 2px rgba(0, 0, 0, 0.15);
        border-radius: 10px;
    }

    .cadastro {
        font-size: 12px;
    }

    .cadastro span {
        color: #406882;
    }
</style>