<script>
    import { tela } from "../store";
    import Cabecalho from "../components/controls/Cabecalho.svelte";
    import ProjetoDescricao from "../components/controls/ProjetoDescricao.svelte";

    let telaProjetos;

    let hour = 0;
    let minute = 0;
    let second = 0;
    let millisecond = 0;

    let cron;
    let iniciar = false;

    function start() {
    if (iniciar == false){
    
        cron = setInterval(() => { timer(); }, 10);
        iniciar = true;
    } else {
        clearInterval(cron);
        iniciar = false
    }

}

    function reset() {
        hour = 0;
        minute = 0;
        second = 0;
        millisecond = 0;
    }

    function timer() {
        if ((millisecond += 10) == 1000) {
            millisecond = 0;
            second++;
        }
        if (second == 60) {
            second = 0;
            minute++;
        }
        if (minute == 60) {
            minute = 0;
            hour++;
        }
    }

    function returnData(input) {
        return input >= 10 ? input : `0${input}`
    }

    function horaProjeto(event) {
        clearInterval(cron);
        telaProjetos.showModal();
    }
</script>

<Cabecalho>
<div class="telaCronometro">
    <form name="form_main">
        <div>
          <span id="hour">{returnData(hour)}</span>:<span id="minute">{returnData(minute)}</span>:<span id="second">{returnData(second)}</span>:<span id="millisecond">{returnData(millisecond)}</span>
        </div>
      
        <br>
      
        <button type="button" name="start" on:click={start}>start</button>
        <button type="button" name="reset" on:click={reset}>reset</button>
      </form>

      <br>

    <div class="btnConfirm">
        <button id="press" type="button" name="prosseguir" on:click={horaProjeto}>
            Confirmar
        </button>
    </div>
    <ProjetoDescricao bind:dialog={telaProjetos}/>
</div>
</Cabecalho>

<style>
    .telaCronometro {
        margin: 20px;
    }

    button#press {
        color: white;
        background: #406882;
        border: 1px solid #000000;
        padding: 4px 78px;
        box-shadow: 0px 3px 2px rgb(0 0 0 / 15%);
        border-radius: 10px;
        margin-top: 10px;
    }
</style>