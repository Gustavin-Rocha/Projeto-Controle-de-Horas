<script lang="ts">
    import { tela } from "../store";
    import Cabecalho from "../components/controls/Cabecalho.svelte";
    import CriarProjeto from "../components/controls/CriarProjeto.svelte";

    let telaProjetos;

    function onAddProject(event){
        telaProjetos.showModal();
    }
</script>

<Cabecalho>

<div class="estatisticas">
    <h1 class="tit1">Estatísticas</h1>

    <div class="grafico">
        <img src="vetores/Frame.svg" alt="Grafico">
    </div>
    
    <h1 class="tit2">Meus Projetos</h1>

    <div class="adicionar">
        <button class="btnAdd" on:click={onAddProject}>
            <img src="vetores/add.svg" alt="Mais">
        </button>
    </div>

    <div class="meusprojetos">
        <div class="coluna1">
            <div class="aptitude">
                <img src="vetores/aptitude.png" alt="Aptitude">
            </div>
            
            <div class="ibw">
                <img src="vetores/ibw.png" alt="Ibw">
            </div>
        </div>
        
        <div class="coluna2">
            <div class="belle">
                <img src="vetores/belle.svg" alt="Belle">
            </div>
    
            <div class="wood">
                <img src="vetores/wood.jpg" alt="RockWood">
            </div>
        </div>
    </div>
    <CriarProjeto bind:dialog={telaProjetos}/>
</div>

</Cabecalho>

<style>
    .estatisticas {
        display: grid;
        justify-items: center;
        justify-content: center;
        margin-top: 30px;
    }

    h1 {
        width: 237px;
        height: 40px;
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 600;
        font-size: 36px;
        line-height: 40px;
    }

    .tit1 {
        margin-top: 0px;
        margin-right: 166px;
        margin-bottom: -12px;
    }

    .tit2 {
        margin-top: 0px;
        margin-right: 116px;
        margin-bottom: 23px;
    }

    .grafico {
        display: flex;
        flex-direction: row;
        align-items: center;
        padding: 20px 7px;
        gap: 30px;
        width: 322.69px;
        height: 164.34px;
    }

    .adicionar {
        margin-left: 290px;
        margin-top: -74px;
    }

    .btnAdd {
        padding: 0px;
        margin: 0px;
        border: none;
        background: transparent;
    }

    .meusprojetos img {
        width: 160px;
        height: 56px;
        margin-bottom: 20px;
    }
    
    .coluna1 {
        display: flex;
    }

    .coluna2 {
        display: flex;
    }
</style>