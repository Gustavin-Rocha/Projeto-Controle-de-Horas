import {writable} from 'svelte/store';

export const tela = writable('padrao');