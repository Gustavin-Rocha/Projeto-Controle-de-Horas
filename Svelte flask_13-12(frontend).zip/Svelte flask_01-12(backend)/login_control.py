from flask import Flask, render_template, request, session, redirect, url_for, send_from_directory
from appwrite.client import Client
from appwrite.id import ID
from appwrite.query import Query
#from appwrite.services.users import Users
#from appwrite.services.database import Databases
from appwrite.services.databases import Databases





client = Client()

(client
.set_endpoint('https://appwrite.tmx.tec.br/v1') # API Endpoint
.set_project('636942cee3445dbc774e')  # project ID
.set_key('edc36bf569aae62ea5c120f7abda2eb4b3077c29dfa5d4356d519d24a27b4d65ab0693e8aa730971198005f817c84493d636993f9535e771f07a368b0bd65454ca4ab909451bdd3b6df26b742656841db3a3f78c51ecb52643f354dbc6bed88fd12d6a0fc3a5ee3984ade0377f83eb23a410ba866d64eee6dadbba1e514075e5') # secret API key
)

databases = Databases(client)


app = Flask(__name__)

app.secret_key = "123456"

@app.route('/')
def base():
  return send_from_directory('client/public', 'index.html')

@app.route("/<path:path>")
def home(path):
    return send_from_directory('client/public', path)

@app.route('/login', methods=["GET", "POST"])
def login_page():

  # Inicializa as variáveis do POST

  acess = False
  args = request.args
  emailsvelte = args['email'] 
  senhasvelte = args['senha']

  # Caso o usuário ou senha não tenha sido informado, retorna erro
  if not all([emailsvelte, senhasvelte]):
   return "Usuário ou senha incorretos"

  # Consulta o banco de dados
  login = databases.list_documents(
    '6369438b481bd9bd8787' , '6377c8d20c8d3021ce88' , 
    [
        Query.equal('email', emailsvelte),
    ])

  # Caso nenhum usuário seja encontrado, retorna erro
  if login == {'total': 0, 'documents': []}:
    return "Usuário ou senha incorretos"

  usuario = login['documents'][0]

  session['usuario'] = usuario


  
  # Valida se a senha é invalida, e retorna erro
  if usuario['password'] != senhasvelte:
    return "Usuário ou senha incorretos"


  # retorna sucesso

  return "Usuário e senha corretos"

@app.route('/user', methods=["GET", "POST"])
def user():
  user = session['usuario']
  name = user['name']
  session['name'] = name

  return name
  
@app.route('/projects', methods = ["GET", "POST"])
def projects():

  user = session['usuario']
  iduser = user["$id"]
  name = user['name']
  data = databases.list_documents(
    '6369438b481bd9bd8787', '63694d8873119cdcfbef',
    [
      Query.equal('user', name),
    ]

  )

  projects = data['documents']

  #if request.method == "GET":
  return render_template('Projetos.html', datauser=name, projects=projects)


  
  
@app.route('/create', methods = ["GET", "POST"])
def create_project():

  user = session['usuario']
  #iduser = user["$id"]
  name = user['name']

  #if request.method == "GET":
    #return render_template('Criar_projeto.html')
  
  args = request.args
  namehtml = args['nomeprojeto']
  priorityhtml = args['prioridade']
  statushtml = args['status']
  
  
  

  #if not all ([namehtml, priorityhtml, statushtml]):
    #return render_template("Criar_projeto.html", htmlmsg="Preencha todos os dados para criar um novo projeto")
  
  # Cria um documento no banco de dados 
  project = databases.create_document('6369438b481bd9bd8787', '63694d8873119cdcfbef', ID.unique(), 
  {"name_project": namehtml, 
  "priority": priorityhtml, 
  "status": statushtml,
  "user": name
  })
  


 

  

if __name__ == "__main__":
    app.run(debug=True)
 



















